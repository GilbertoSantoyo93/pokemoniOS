//
//  ViewController.swift
//  pokemoniOS
//
//  Created by Gilberto Santoyo on 7/5/19.
//  Copyright © 2019 Gilberto Santoyo. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    var pokemonListModel : PokemonListModel!
    
    @IBOutlet weak var btnPrevious: UIBarButtonItem!
   
    @IBOutlet weak var btnNext: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.setupInitClass()
    }
    
    func setupInitClass () {
        self.downloadPokemonList(urlString: "https://pokeapi.co/api/v2/pokemon")
        self.setupTableView()
    }
    
    func setupTableView () {
        
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.register(UINib.init(nibName: "PokemonListCellTableViewCell", bundle: nil), forCellReuseIdentifier: "pokemonCell")
        self.tableView.reloadData()
    }
    
    func downloadPokemonList(urlString : String) {
        let downloadClass = DownloadClass.init()
        downloadClass.getRequestWithUrl(urlString: urlString, success: { (responseData) in
            if(responseData is NSDictionary){
                self.setModelWith(dictionary: (responseData as! NSDictionary))
            } else {
                print("Error data download")
                self.messageDialog(title: "Error en la descarga", descriptionText: "Verífica tu conexión a internet e intentalo nuevamente")
            }
        }) { (errorData) in
            print(errorData)
            self.messageDialog(title: "Error en la descarga", descriptionText: "Verífica tu conexión a internet e intentalo nuevamente")
        }
    }
    
    func messageDialog(title : String, descriptionText: String) {
        let alert = UIAlertController(title: title, message: descriptionText, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Aceptar", style: UIAlertAction.Style.default, handler: { _ in
            
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    func setModelWith(dictionary: NSDictionary) {
        self.pokemonListModel = PokemonListModel.init(nDictionary: dictionary)
        if self.pokemonListModel.next != "" {
            self.btnNext.isEnabled = true
        } else {
            self.btnNext.isEnabled = false
        }
        if self.pokemonListModel.previous != "" {
            self.btnPrevious.isEnabled = true
        } else {
            self.btnPrevious.isEnabled = false
        }
        self.tableView.reloadData()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (self.pokemonListModel != nil) {
            if (self.pokemonListModel.pokemonArray.count > 0) {
                return self.pokemonListModel.pokemonArray.count
            }
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "pokemonCell") as! PokemonListCellTableViewCell
        if (self.pokemonListModel != nil) {
            if (self.pokemonListModel.pokemonArray.count > 0) {
                cell.setUpdateData(nModel: (self.pokemonListModel.pokemonArray.object(at: indexPath.row) as! PokemonModel))
            }
        }
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.pokemonListModel != nil {
            if (self.pokemonListModel.pokemonArray.count > 0) {
                let modelTemp = (self.pokemonListModel.pokemonArray.object(at: indexPath.row) as! PokemonModel)
                if (modelTemp.url != "") {
                    self.getDownloadURL(urlString: modelTemp.url)
                } 
                
            } 
        }
    }
    
    func getDownloadURL(urlString: String) {
        let downloadClass = DownloadClass.init()
        downloadClass.getRequestWithUrl(urlString: urlString, success: { (responseData) in
            if(responseData is NSDictionary){
                self.setModel(nDictionary: (responseData as! NSDictionary))
            } else {
                print("Error data download")
                self.messageDialog(title: "Error en la descarga", descriptionText: "Verífica tu conexión a internet e intentalo nuevamente")
            }
        }) { (errorData) in
            print(errorData)
            self.messageDialog(title: "Error en la descarga", descriptionText: "Verífica tu conexión a internet e intentalo nuevamente")
        }
    }
    
    func setModel(nDictionary : NSDictionary) {
        let modelTemp = PokemonDetailModel.init(nDictionary: nDictionary)
        let nController = PokemonDetailViewController(nibName: "PokemonDetailViewController", bundle: nil, detailModel: modelTemp)
        
        self.present(nController, animated: true, completion: nil)
    }
    
    
    @IBAction func btnItemNextAction(_ sender: Any) {
        if self.pokemonListModel != nil {
            if self.pokemonListModel.next != "" {
                self.downloadPokemonList(urlString: self.pokemonListModel.next)
            } else {
                self.btnNext.isEnabled = false
            }
        }
    }
    @IBAction func btnItemPreviousAction(_ sender: Any) {
        if self.pokemonListModel != nil {
            if self.pokemonListModel.previous != "" {
                self.downloadPokemonList(urlString: self.pokemonListModel.previous)
            } else {
                self.btnPrevious.isEnabled = false
            }
        }
    }
}

