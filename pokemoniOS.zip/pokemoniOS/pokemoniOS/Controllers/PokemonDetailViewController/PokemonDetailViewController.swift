//
//  PokemonDetailViewController.swift
//  pokemoniOS
//
//  Created by Gilberto Santoyo on 7/5/19.
//  Copyright © 2019 Gilberto Santoyo. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireImage

class PokemonDetailViewController: UIViewController {

    @IBOutlet weak var imgPokemon: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblExperiencie: UILabel!
    
    @IBOutlet weak var lblHeight: UILabel!
    @IBOutlet weak var lblWeight: UILabel!
    
    var pokemonDetailModel : PokemonDetailModel!
    
    init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?, detailModel: PokemonDetailModel) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        self.pokemonDetailModel = detailModel
    }
    
    @IBAction func btnBackItemAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.setupController()
    }
    
    func setupController() {
        if self.pokemonDetailModel != nil {
            self.lblName.text = self.pokemonDetailModel.name
            self.lblHeight.text = String(format: "%d ft", self.pokemonDetailModel.height)
            self.lblWeight.text = String(format: "%d lbs", self.pokemonDetailModel.weight)
            self.lblExperiencie.text = String(format: "%d pts", self.pokemonDetailModel.base_experience)
            if (self.pokemonDetailModel.imagePokemon != "") {
                self.getImage(self.pokemonDetailModel.imagePokemon) { (imageData) in
                    if (imageData != nil) {
                        self.imgPokemon.image = imageData
                    }
                }
            } 
        }
    }
    
    func getImage(_ url:String,handler: @escaping (UIImage?)->Void) {
        Alamofire.request(url, method: .get).responseImage { response in
            if let data = response.result.value {
                handler(data)
            } else {
                handler(nil)
            }
        }
    }
    
    @IBAction func btnBackAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
}
