//
//  PokemonListModel.swift
//  pokemoniOS
//
//  Created by Gilberto Santoyo on 7/5/19.
//  Copyright © 2019 Gilberto Santoyo. All rights reserved.
//

import UIKit

class PokemonListModel: NSObject {
    
    var count : Int!
    var next : String!
    var previous : String!
    var pokemonArray : NSMutableArray!
    var jsonRaw : NSDictionary
    
    init(nDictionary : NSDictionary) {
            
        self.jsonRaw = nDictionary
        
        if (jsonRaw.object(forKey: "count") as? Int) != nil {
            self.count = (self.jsonRaw.object(forKey: "count") as! Int)
        } else {
            self.count = 0
        }
        
        if (jsonRaw.object(forKey: "next") as? String) != nil {
            self.next = (self.jsonRaw.object(forKey: "next") as! String)
        } else {
            self.next = ""
        }
        
        if (jsonRaw.object(forKey: "previous") as? String) != nil {
            self.previous = (self.jsonRaw.object(forKey: "previous") as! String)
        } else {
            self.previous = ""
        }
        
        if (jsonRaw.object(forKey: "previous") as? String) != nil {
            self.previous = (self.jsonRaw.object(forKey: "previous") as! String)
        } else {
            self.previous = ""
        }
        
        if (jsonRaw.object(forKey: "previous") as? String) != nil {
            self.previous = (self.jsonRaw.object(forKey: "previous") as! String)
        } else {
            self.previous = ""
        }
        
        self.pokemonArray = NSMutableArray.init()
        if let nArray = jsonRaw.object(forKey: "results") as? NSArray {
            if(nArray.count > 0) {
                for nArrays in nArray {
                    if nArrays is NSDictionary {
                        let pokemonTemp = PokemonModel.init(nDictionary: (nArrays as! NSDictionary))
                        self.pokemonArray.add(pokemonTemp)
                    }
                }
            }
        } 
        
        super.init()
        
    }
    
}
