//
//  PokemonModel.swift
//  pokemoniOS
//
//  Created by Gilberto Santoyo on 7/5/19.
//  Copyright © 2019 Gilberto Santoyo. All rights reserved.
//

import UIKit

class PokemonModel: NSObject {
    var name : String!
    var url:String!
    var jsonRaw : NSDictionary!
    
    init(nDictionary : NSDictionary) {
        self.jsonRaw = nDictionary
        
        if (jsonRaw.object(forKey: "name") as? String) != nil {
            self.name = (self.jsonRaw.object(forKey: "name") as! String)
        } else {
            self.name = ""
        }
        
        if (jsonRaw.object(forKey: "url") as? String) != nil {
            self.url = (self.jsonRaw.object(forKey: "url") as! String)
        } else {
            self.url = ""
        }
        super.init()
    }
}
