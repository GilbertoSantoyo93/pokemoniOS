//
//  PokemonDetailModel.swift
//  pokemoniOS
//
//  Created by Gilberto Santoyo on 7/5/19.
//  Copyright © 2019 Gilberto Santoyo. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireImage

class PokemonDetailModel: NSObject {
    
    var idPokemon : Int!
    var base_experience : Int!
    var height : Int!
    var weight : Int!
    var abilities : NSDictionary!
    var name : String!
    var is_default : Bool!
    var imagePokemon : String!
    var jsonRaw : NSDictionary!
    
    init(nDictionary : NSDictionary) {
        super.init()
        self.jsonRaw = nDictionary    
        
        
        if (jsonRaw.object(forKey: "id") as? Int) != nil {
            self.idPokemon = (self.jsonRaw.object(forKey: "id") as! Int)
        } else {
            self.idPokemon = 0
        }
        
        if (jsonRaw.object(forKey: "base_experience") as? Int) != nil {
            self.base_experience = (self.jsonRaw.object(forKey: "base_experience") as! Int)
        } else {
            self.base_experience = 0
        }
        
        if (jsonRaw.object(forKey: "height") as? Int) != nil {
            self.height = (self.jsonRaw.object(forKey: "height") as! Int)
        } else {
            self.height = 0
        }
        
        if (jsonRaw.object(forKey: "weight") as? Int) != nil {
            self.weight = (self.jsonRaw.object(forKey: "weight") as! Int)
        } else {
            self.weight = 0
        }
        
        if (jsonRaw.object(forKey: "weight") as? Int) != nil {
            self.weight = (self.jsonRaw.object(forKey: "weight") as! Int)
        } else {
            self.weight = 0
        }
        
        if (jsonRaw.object(forKey: "abilities") as? NSDictionary) != nil {
            self.abilities = (self.jsonRaw.object(forKey: "abilities") as! NSDictionary)
        } else {
            self.abilities = nil
        }
        
        if (jsonRaw.object(forKey: "abilities") as? NSDictionary) != nil {
            self.abilities = (self.jsonRaw.object(forKey: "abilities") as! NSDictionary)
        } else {
            self.abilities = nil
        }
        
        if (jsonRaw.object(forKey: "name") as? String) != nil {
            self.name = (self.jsonRaw.object(forKey: "name") as! String)
        } else {
            self.name = ""
        }
        
        if let dictTemp = jsonRaw.object(forKey: "sprites") as? NSDictionary {
            if(dictTemp.count > 0) {
                if (dictTemp.object(forKey: "front_default") as? String) != nil {
                    self.imagePokemon = (dictTemp.object(forKey: "front_default") as! String)
                } else {
                    self.imagePokemon = nil
                }
            }
        }
        
    }
    
}
