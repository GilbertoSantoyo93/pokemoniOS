//
//  DownloadClass.swift
//  pokemoniOS
//
//  Created by Gilberto Santoyo on 7/5/19.
//  Copyright © 2019 Gilberto Santoyo. All rights reserved.
//

import UIKit
import Alamofire
class DownloadClass: NSObject {
    
    override init() {
        super.init()
    }
    
    func getRequestWithUrl(urlString: String, success onSuccess: @escaping (_ responseObject: AnyObject) -> Void, onFailure:@escaping (_ failure: AnyObject) -> Void ) {
//        let headers: HTTPHeaders = [
//            "Accept": "application/json",
//                        "Content-Type": "application/json"
//        ]
        Alamofire.request(urlString).responseJSON { (responseData) in
            if responseData.response?.statusCode == 200 {
                onSuccess(responseData.result.value as AnyObject)
            } else {
                onFailure(responseData as AnyObject)
            }
        }
            
    }
    
}
